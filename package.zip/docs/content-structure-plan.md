# Content Structure Plan - Aurora Brew

## 1. Material Inventory

**Note**: This is a portfolio demonstration website. Content structure is designed to showcase premium cafe website patterns identified in research (Intelligentsia, Stumptown, La Colombe, George Howell, Counter Culture).

**Content Sections**:
- Homepage hero + brand story (600 words)
- Coffee menu with flavor profiles (12 items × 80 words = 960 words)
- Brewing education content (400 words)
- Location & hours information (200 words)
- Subscription program details (300 words)
- About/Our Story section (500 words)
- Total estimated: ~3,000 words

**Visual Assets** (to be created/sourced):
- Hero imagery: Coffee brewing, ambient cafe scenes
- Product photography: Coffee bags, brewing equipment
- Lifestyle imagery: Customer experience, barista craft
- Brand elements: Logo, iconography
- Estimated: 15-20 high-quality images

**Data Requirements**:
- Menu items with flavor notes (12 coffee varieties)
- Brewing guide steps (3-4 methods)
- Location details (hours, address, map integration)
- Subscription tiers (3 levels)

## 2. Website Structure

**Type**: Single Page Application (SPA)

**Reasoning**: 
- Content volume: ~3,000 words fits within SPA threshold
- Single cohesive goal: Establish premium brand + drive subscriptions/visits
- <5 main sections with unified narrative flow
- Portfolio showcase benefits from seamless scroll experience
- Enables kinetic typography and scroll-triggered animations effectively

## 3. Section Breakdown

### Section 1: Hero Landing
**Purpose**: Immediate brand impact + establish premium positioning

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Hero | Grand Hero Pattern (600-800px) | Brand tagline "Where Heritage Meets Innovation" + primary CTA | Hero background (ambient cafe scene with brewing) |
| Animated Headline | Kinetic Typography | "Aurora Brew" + rotating descriptors ("Artisan Coffee", "Premium Roasting", "Craft Experience") | - |

**Design Treatment**: Full-width hero with 50% dark gradient overlay, 96px Playfair Display headline with kinetic scroll animation, 64px CTA button with metallic gradient accent.

---

### Section 2: Brand Introduction (Bento Grid)
**Purpose**: Multi-dimensional brand story through modular content blocks

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Story Block (Large) | Bento Grid - Feature Card (7 cols) | Company origin story, craft approach (300 words) | Founder portrait or roasting process |
| Values Grid (Small) | Bento Grid - 4 Icon Cards (5 cols) | 4 core values: Heritage, Quality, Community, Sustainability | Icon set (SVG) |
| Statistics Bar | Bento Grid - Data Cards (full width) | Years in business, beans sourced, customers served, locations | - |

**Design Treatment**: CSS Grid with named areas, asymmetric 7/5 split, cards with 48-64px padding, subtle Mocha brown (#A47864) backgrounds on cream (#FBF7F4), scroll-triggered fade-in reveals.

---

### Section 3: Coffee Menu (Featured Collection)
**Purpose**: Showcase premium coffee selection with flavor profiling

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Menu Header | Section Title + Filter Tabs | "Our Collection" + filters (All, Light Roast, Medium, Dark, Espresso) | - |
| Coffee Cards | Product Card Grid (3-4 col) | 12 coffee varieties with: Name, origin, roast level, flavor notes, price | Product photography (coffee bags) |
| Flavor Profile Detail | Card Overlay on Hover | Expanded flavor wheel, brewing recommendations, tasting notes | - |

**Design Treatment**: Horizontal filter tabs (modern, not sidebar), 3-column grid → 1-column mobile, product cards with 48px padding, hover state reveals metallic border (bronze gradient), micro-animation on card lift (400ms).

---

### Section 4: Brewing Mastery Hub
**Purpose**: Educational content to establish expertise and aid discovery

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Guide Cards | 2-Column Split Layout | 3 brewing methods: Pour Over, French Press, Espresso (each ~120 words) | Step-by-step photography |
| Coffee Quiz CTA | Featured CTA Card | "Find Your Perfect Brew" - leads to personalized coffee quiz | Illustration or icon |
| Video Embed (Optional) | Ambient Video Player | Silent looped brewing demonstration (30-45 sec) | Video content |

**Design Treatment**: 50/50 split layout on desktop, guide cards with serif numbered steps, quiz CTA with rich orange (#E2725B) background and 64px button, ambient video with backdrop-blur overlay.

---

### Section 5: Subscription Program
**Purpose**: Drive recurring revenue through subscription conversion

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Program Headline | Section Title | "Join Our Coffee Club" + value proposition | - |
| Tier Cards | 3-Column Pricing Cards | 3 tiers: Explorer (1 bag/month), Enthusiast (2 bags), Connoisseur (4 bags + perks) | - |
| Benefits List | Icon + Text List | Free shipping, early access, flexible scheduling, cancel anytime | SVG icon set |
| Configuration UI | Interactive Form | Frequency selector, quantity selector, preference toggles | - |

**Design Treatment**: Pricing cards with 64px padding, deep purple (#6B4C7A) accent for "Recommended" tier, metallic gold gradient on primary CTA, hover state with gentle lift (400ms), subscription benefits with emerald green (#2D5C4F) checkmark icons.

---

### Section 6: Location & Visit
**Purpose**: Drive foot traffic and provide wayfinding

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Location Details | 2-Column Layout (60/40) | Address, hours, contact, parking info | - |
| Map Embed | Interactive Map | Google Maps integration with cafe marker | - |
| Cafe Gallery | 3-Image Grid | Interior ambiance shots showcasing seating, bar, atmosphere | Photography (3 images) |

**Design Treatment**: Map on left (60%), details on right (40%), emerald green (#2D5C4F) location pin icon, gallery images with 12px radius and 1px warm border, scroll-triggered reveal animation.

---

### Section 7: Footer Navigation
**Purpose**: Secondary navigation, social links, legal

**Content Mapping:**

| Section | Component Pattern | Content to Extract | Visual Asset |
|---------|------------------|-------------------|--------------|
| Footer Menu | 4-Column Grid | Shop, Learn, Visit, About sections with sub-links | - |
| Newsletter Signup | Email Capture Form | "Stay Updated" + email input + submit CTA | - |
| Social Links | Icon Row | Instagram, Facebook, Twitter handles | SVG icon set |
| Legal/Accessibility | Small Text Links | Privacy Policy, Terms, Accessibility Statement | - |

**Design Treatment**: Warm neutral-700 (#4A4A45) text on warm neutral-50 (#F5F4F0) background, 80-96px footer height, social icons with 24px size, newsletter CTA with metallic accent.

---

## 4. Content Analysis

**Information Density**: Medium
- ~3,000 words across 7 sections (appropriate for premium SPA)
- 12 product items (coffee menu)
- 3 brewing guides
- 3 subscription tiers
- Educational + transactional content balanced

**Content Balance**:
- Images: 15-20 estimated (40%)
- Text: ~3,000 words (35%)
- Interactive Elements: Quiz, subscription configurator, map (25%)
- **Content Type**: Mixed (visual-focused with educational depth)

**Portfolio Showcase Opportunities**:
- **Advanced CSS**: Bento grid with named areas, CSS custom properties, GPU-accelerated animations
- **Kinetic Typography**: Scroll-triggered headline animations on hero
- **Micro-interactions**: Button hover states, card lifts, filter transitions
- **Responsive Design**: Mobile-first breakpoints, touch-friendly 56-64px targets
- **Performance**: Lazy loading, WebP images, ambient video optimization
- **Accessibility**: WCAG AAA contrast, reduced-motion fallbacks, skip links
