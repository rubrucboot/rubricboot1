# Design Specification - Aurora Brew

**Version**: 1.0 | **Style**: Modern Heritage Premium | **Date**: 2025-11-18

---

## 1. Direction & Rationale

**Style Essence**: Modern Heritage Premium blends 2025's grounded warmth (Mocha Mousse as PANTONE Color of the Year anchor) with timeless luxury restraint. Aurora Brew's design conveys craft coffee excellence through generous spacing, refined serif typography, and a rich earth-tone palette that feels both established and contemporary. This approach demonstrates cutting-edge web design skills—Bento grid layouts, kinetic typography, scroll-triggered animations, and tokenized CSS theming—while maintaining the elegant restraint expected of premium hospitality brands.

**Real-World References**:
- **La Colombe Coffee**: Luxury execution, video storytelling, accessibility controls
- **George Howell Coffee**: Premium heritage, educational depth via Exploratorium
- **Stumptown Coffee Roasters**: Modern minimalism with Builder.io modular content
- **Intelligentsia Coffee**: Comprehensive navigation, craftsmanship-first positioning

**Design Philosophy**: 60% warm neutrals create breathable backgrounds; 30% deep accents (purple, emerald) provide structural rhythm; 10% vibrant highlights (rich orange) drive action. Playfair Display headlines at 64-96px establish brand voice through kinetic scroll effects; Inter Pro body text ensures clarity. Spatial generosity (96-128px section gaps, 48-64px card padding) elevates perceived value while Bento grids and scroll animations showcase 2025 technical mastery.

---

## 2. Design Tokens

### 2.1 Color System

**Primary Palette** (60% - Warm Neutrals)

| Token | Hex | Usage | WCAG |
|-------|-----|-------|------|
| `--color-mocha-50` | `#FBF7F4` | Page background (cream) | Base |
| `--color-mocha-100` | `#F5F0EB` | Card backgrounds, surface elevation | Base |
| `--color-mocha-500` | `#A47864` | Brand accent, section dividers | 4.8:1 on cream ✅ AA |
| `--color-mocha-700` | `#7A5A49` | Subdued accents, borders | 7.2:1 on cream ✅ AAA |
| `--color-mocha-900` | `#4D3A2E` | Deep warm text (optional) | 12.1:1 on cream ✅ AAA |

**Accent Palette** (30% - Deep Accents)

| Token | Hex | Usage | WCAG |
|-------|-----|-------|------|
| `--color-purple-500` | `#6B4C7A` | Navigation, subscription tier highlights | 6.5:1 on cream ✅ AA |
| `--color-purple-700` | `#523B5E` | Hover states, active elements | 9.1:1 on cream ✅ AAA |
| `--color-emerald-500` | `#2D5C4F` | Success indicators, checkmarks, location pins | 7.8:1 on cream ✅ AAA |
| `--color-emerald-700` | `#1F443A` | Deep emerald for emphasis | 11.3:1 on cream ✅ AAA |

**Highlight Palette** (10% - Vibrant CTAs)

| Token | Hex | Usage | WCAG |
|-------|-----|-------|------|
| `--color-orange-500` | `#E2725B` | Primary CTAs, hover accents | 4.6:1 on cream ✅ AA |
| `--color-orange-600` | `#D5634D` | CTA hover states | 5.2:1 on cream ✅ AA |
| `--color-orange-amber` | `#D97D3A` | Secondary CTAs, metallic gradients | 5.1:1 on cream ✅ AA |

**Neutral System**

| Token | Hex | Usage | WCAG |
|-------|-----|-------|------|
| `--color-neutral-50` | `#FAFAF8` | Alternative light background | Base |
| `--color-neutral-200` | `#E8E6E0` | Borders, dividers | N/A |
| `--color-neutral-500` | `#9B9A94` | Placeholder text, muted content | 3.2:1 (decorative) |
| `--color-neutral-700` | `#4A4A45` | Secondary text | 8.5:1 on cream ✅ AAA |
| `--color-neutral-900` | `#1C1C19` | Primary text (charcoal) | 15.2:1 on cream ✅ AAA |

**Semantic Tokens**

| Token | Mapping | Purpose |
|-------|---------|---------|
| `--color-bg-primary` | `--color-mocha-50` | Page background |
| `--color-surface-elevated` | `--color-mocha-100` | Cards, elevated components |
| `--color-text-primary` | `--color-neutral-900` | Body text, headings |
| `--color-text-secondary` | `--color-neutral-700` | Subheadings, captions |
| `--color-accent-cta` | `--color-orange-500` | Primary action buttons |
| `--color-accent-brand` | `--color-mocha-500` | Brand moments, icons |

**WCAG Validation** (Key Pairings):
- Charcoal (#1C1C19) on Cream (#FBF7F4): **15.2:1** ✅ AAA
- Secondary (#4A4A45) on Cream: **8.5:1** ✅ AAA
- Purple (#6B4C7A) on Cream: **6.5:1** ✅ AA

### 2.2 Typography

**Font Families**

| Token | Value | Weights | Fallback Stack |
|-------|-------|---------|----------------|
| `--font-display` | `'Playfair Display'` | 400, 600, 700 | `Georgia, 'Times New Roman', serif` |
| `--font-body` | `'Inter'` | 300, 400, 500, 600 | `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif` |

**Type Scale** (Desktop 1920px)

| Token | Size | Weight | Line Height | Letter Spacing | Use Case |
|-------|------|--------|-------------|----------------|----------|
| `--text-display` | `96px` | 700 (Playfair) | 1.1 | -0.01em | Hero headline |
| `--text-h1` | `72px` | 700 (Playfair) | 1.15 | -0.01em | Section headlines |
| `--text-h2` | `48px` | 600 (Playfair) | 1.2 | 0 | Subsection headlines |
| `--text-h3` | `32px` | 600 (Inter) | 1.3 | 0.01em | Card titles |
| `--text-body-lg` | `20px` | 400 (Inter) | 1.7 | 0 | Intro paragraphs |
| `--text-body` | `18px` | 400 (Inter) | 1.6 | 0.01em | Standard body |
| `--text-small` | `14px` | 400 (Inter) | 1.5 | 0.02em | Captions, labels |
| `--text-caption` | `12px` | 500 (Inter) | 1.4 | 0.05em | Uppercase labels |

**Responsive Type Scale** (Mobile <768px)

| Token | Desktop | Mobile | Adjustment |
|-------|---------|--------|------------|
| `--text-display` | 96px | 56px | -41% |
| `--text-h1` | 72px | 40px | -44% |
| `--text-h2` | 48px | 32px | -33% |
| `--text-body` | 18px | 18px | Maintained (premium readability) |

**Typographic Refinements**:
- Enable ligatures: `font-feature-settings: "liga" 1, "kern" 1`
- Optical alignment: Manual `translateY()` adjustments for headline positioning
- Widow prevention: `orphans: 3; widows: 3`
- Line length: 55-65 characters (~550-650px at 18px)

### 2.3 Spacing System (8pt Grid)

| Token | Value | Usage |
|-------|-------|-------|
| `--space-1` | `8px` | Inline micro-spacing |
| `--space-2` | `16px` | Tight element spacing |
| `--space-3` | `24px` | Standard gaps |
| `--space-4` | `32px` | Related group spacing |
| `--space-6` | `48px` | Card padding (minimum) |
| `--space-8` | `64px` | Large card padding, section internal |
| `--space-12` | `96px` | Section boundaries |
| `--space-16` | `128px` | Dramatic luxury spacing |
| `--space-20` | `160px` | Hero section vertical padding |

**Spatial Strategy**: 
- Section gaps: 96-128px
- Card padding: 48-64px (never less than 48px)
- Content:whitespace ratio: 55:45 (general), 40:60 (hero)

### 2.4 Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| `--radius-sm` | `8px` | Buttons, inputs |
| `--radius-md` | `12px` | Cards, images |
| `--radius-lg` | `16px` | Modals, large components |
| `--radius-full` | `9999px` | Pills, circular buttons |

### 2.5 Shadows (Layered Soft)

| Token | Value | Usage |
|-------|-------|-------|
| `--shadow-card` | `0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.04)` | Default card elevation |
| `--shadow-card-hover` | `0 12px 24px rgba(0,0,0,0.12), 0 6px 12px rgba(0,0,0,0.06)` | Card hover state |
| `--shadow-modal` | `0 24px 48px rgba(0,0,0,0.15), 0 12px 24px rgba(0,0,0,0.08)` | Modal, prominent overlays |

### 2.6 Animation Timing

| Token | Value | Purpose |
|-------|-------|---------|
| `--duration-fast` | `250ms` | Quick feedback (button press) |
| `--duration-normal` | `400ms` | Standard transitions (card hover) |
| `--duration-slow` | `600ms` | Luxury moments (page transitions) |
| `--easing-standard` | `cubic-bezier(0.4, 0.0, 0.2, 1)` | Material Design easing |
| `--easing-elegant` | `cubic-bezier(0.25, 0.46, 0.45, 0.94)` | Refined ease-out |

---

## 3. Component Specifications

### 3.1 Hero Section (Grand Statement)

**Structure**:
- Full-viewport height (600-800px)
- Background: Full-bleed image with 50% dark overlay (`linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.6))`)
- Content: Centered vertical + horizontal alignment
- Padding: 160px vertical (generous luxury spacing)

**Tokens**:
- Headline: `--text-display` (96px Playfair Bold), white text
- Subheadline: `--text-body-lg` (20px Inter), white text with 70% opacity
- CTA Button: 64px height, `--color-orange-500` with metallic gradient option
- Background: Ambient cafe imagery, 4K resolution, WebP format

**States**:
- **Default**: Kinetic typography animation on headline (see §5.2)
- **Scroll**: Subtle parallax (background moves 50% scroll speed)
- **Reduced Motion**: Static layout, no kinetic animation, fade-in only

**Note**: Headline uses rotating descriptors ("Artisan Coffee" → "Premium Roasting" → "Craft Experience") with 400ms crossfade transitions. Ensure `prefers-reduced-motion: reduce` disables rotation.

### 3.2 Button (Primary CTA)

**Structure**:
- Height: 56-64px (64px for hero, 56px for inline)
- Padding: 32px horizontal, 20px vertical
- Border radius: `--radius-sm` (8px)
- Font: Inter Medium 500, 16px, letter-spacing 0.05em

**Tokens**:
- Background: `--color-orange-500` (solid) or metallic bronze gradient (accent moments)
- Text: White (#FFFFFF)
- Shadow: `--shadow-card` (default state)

**States**:
- **Hover**: `brightness(1.1)` + `translateY(-2px)` + `--shadow-card-hover`, 300ms transition
- **Active**: `scale(0.98)`, 150ms transition
- **Focus**: 2px solid `--color-orange-600` outline, 0 offset
- **Disabled**: 40% opacity, cursor not-allowed

**Metallic Gradient Option** (Hero CTA only):
```css
background: linear-gradient(135deg, #CD7F32 0%, #E8C59A 50%, #B8691E 100%);
```

### 3.3 Card (Product/Content)

**Structure**:
- Padding: 48-64px (48px mobile, 64px desktop)
- Background: `--color-surface-elevated` (#F5F0EB)
- Border radius: `--radius-md` (12px)
- Border: Optional 1px `--color-neutral-200`
- Shadow: `--shadow-card`

**Tokens**:
- Title: `--text-h3` (32px Inter Semibold)
- Body: `--text-body` (18px Inter Regular)
- Accent: `--color-mocha-500` for icons/labels

**States**:
- **Default**: Shadow `--shadow-card`, no transform
- **Hover**: `translateY(-4px)` + `--shadow-card-hover` + 1px metallic border reveal (bronze), 400ms elegant easing
- **Focus**: 2px solid `--color-purple-500` outline

**Bento Grid Variant**: Asymmetric sizing in CSS Grid, larger cards 7 cols, smaller 5 cols on 12-column base.

### 3.4 Navigation Bar

**Structure**:
- Height: 80-96px (80px scroll state, 96px top position)
- Background: `--color-neutral-50` (#FAFAF8) with 95% opacity backdrop-blur(20px)
- Shadow: `0 2px 8px rgba(0,0,0,0.06)` (appears on scroll)
- Position: Fixed top, z-index 1000

**Tokens**:
- Logo: 48px height, `--color-mocha-500`
- Nav links: `--text-small` (14px Inter Light 300), `--color-neutral-700`, letter-spacing 0.1em
- CTA button: 48px height, `--color-orange-500`

**Layout**:
- Logo: Left aligned, 24px margin
- Nav links: Center (desktop), horizontal flex gap 32px
- CTA: Right aligned, 24px margin
- Mobile: Hamburger icon (24px), slide-in menu overlay

**States**:
- **Link Hover**: `color: --color-purple-500`, 200ms transition
- **Scroll State**: Background opacity increases to 98%, shadow appears
- **Mobile Menu**: Full-screen overlay with backdrop-blur, slide-in from right (400ms)

### 3.5 Input Field

**Structure**:
- Height: 56-64px
- Padding: 20px horizontal, 16px vertical
- Border radius: `--radius-sm` (8px)
- Border: 1px solid `--color-neutral-200`

**Tokens**:
- Font: `--text-body` (18px Inter Light 300)
- Placeholder: `--color-neutral-500`
- Text: `--color-neutral-900`

**States**:
- **Default**: 1px neutral border
- **Focus**: 1.5px solid `--color-purple-500`, no shadow (elegant)
- **Error**: 1.5px solid `--color-orange-500`, error message in `--text-small`
- **Success**: 1.5px solid `--color-emerald-500`

### 3.6 Subscription Tier Card (Project-Specific)

**Structure**:
- Padding: 64px
- Background: `--color-surface-elevated` with optional `--color-purple-500` border for "Recommended" tier
- Border radius: `--radius-md` (12px)
- Shadow: `--shadow-card`

**Tokens**:
- Tier Name: `--text-h3` (32px Inter Semibold)
- Price: `--text-h1` (72px Playfair Bold), `--color-mocha-500`
- Features: `--text-body` (18px Inter), emerald checkmark icons (24px SVG)
- CTA: Primary button (§3.2)

**States**:
- **Recommended Tier**: 2px `--color-purple-500` border, "Recommended" badge in purple
- **Hover**: Gentle lift (-4px) + shadow increase, metallic accent reveal on CTA
- **Selected**: Border changes to `--color-emerald-500`, checkmark icon in top-right

**Layout**: 3-column grid (desktop) → 1-column stack (mobile), 32px gap between cards.

---

## 4. Layout & Responsive Strategy

### 4.1 Website Architecture (SPA)

**Section Flow** (Based on content-structure-plan.md):
1. **Hero Landing** (600-800px): Full-viewport with kinetic headline
2. **Brand Introduction** (auto): Bento grid with asymmetric 7/5 split
3. **Coffee Menu** (auto): Horizontal filters + 3-col product grid
4. **Brewing Mastery Hub** (auto): 2-col guide layout + ambient video
5. **Subscription Program** (auto): 3-col pricing cards
6. **Location & Visit** (auto): 60/40 map + details split
7. **Footer** (auto): 4-col navigation grid

**Visual Hierarchy**:
- Hero: 600-800px dominant presence
- Sections: Auto-height with 96-128px vertical gaps
- Prominence: Hero > Subscription > Menu > Other sections

**Navigation Pattern**: Fixed header with smooth scroll anchor links, mobile hamburger menu.

**Transitions**: Smooth scroll behavior (`scroll-behavior: smooth`), scroll-triggered fade-in reveals (see §5.3).

### 4.2 Grid System

**Base Grid**: 12-column with 32px gutters (desktop), 16px gutters (mobile)

**Container Max-Width**:
- Desktop (>1280px): 1400px
- Tablet (768-1279px): 100% with 48px side padding
- Mobile (<768px): 100% with 24px side padding

**Common Column Patterns**:
- **Hero**: Full-width (12 cols)
- **Bento Grid**: 7/5 asymmetric (Feature 7 cols, Secondary 5 cols)
- **Product Grid**: 4 cols desktop → 2 cols tablet → 1 col mobile
- **Split Layout**: 6/6 (50/50) or 7/5 (60/40)

### 4.3 Breakpoints

| Breakpoint | Width | Container | Adjustments |
|------------|-------|-----------|-------------|
| `sm` | 640px | 100% | Mobile landscape, reduce spacing 30% |
| `md` | 768px | 100% | Tablet portrait, 2-col grids |
| `lg` | 1024px | 1200px | Tablet landscape, 3-col grids |
| `xl` | 1280px | 1400px | Desktop, full experience |
| `2xl` | 1536px | 1600px | Large desktop, max luxury spacing |

### 4.4 Responsive Patterns

**Typography**:
- Display: 96px → 56px (mobile)
- H1: 72px → 40px (mobile)
- Body: 18px maintained (premium readability)

**Spacing**:
- Section gaps: 128px → 80px (mobile)
- Card padding: 64px → 48px (mobile)

**Components**:
- Navigation: Horizontal links → Hamburger menu (<1024px)
- Product grid: 4 cols → 2 cols (tablet) → 1 col (mobile)
- Subscription cards: 3 cols → 1 col stack (mobile)

**Touch Targets**: Minimum 56px height on all interactive elements (buttons, links, inputs).

### 4.5 Performance Strategy

**Images**:
- Format: WebP with JPEG fallback
- Hero: 4K resolution (3840×2160), lazy load below-fold
- Products: 1200px width, srcset for responsive delivery
- Lazy loading: `loading="lazy"` attribute on non-critical images

**Animations**:
- GPU-accelerated only: `transform`, `opacity`
- Preload critical fonts: `<link rel="preload" href="playfair-display.woff2">`
- Reduced motion: Disable kinetic typography, reduce animation durations to 150ms

---

## 5. Interaction Guidelines

### 5.1 Micro-Animations (All Interactions)

**Button Hover**:
- Transform: `scale(1.02)` + `translateY(-2px)`
- Filter: `brightness(1.1)`
- Duration: 300ms
- Easing: `--easing-standard`

**Card Hover**:
- Transform: `translateY(-4px)`
- Shadow: `--shadow-card` → `--shadow-card-hover`
- Border: Metallic bronze gradient reveal (1px)
- Duration: 400ms
- Easing: `--easing-elegant`

**Input Focus**:
- Border: 1px → 1.5px solid `--color-purple-500`
- Duration: 200ms
- No shadow (elegant restraint)

### 5.2 Kinetic Typography (Hero)

**Implementation**:
- Headline: "Aurora Brew" static
- Subheadline: Rotating descriptors with crossfade
- Animation: Fade out (200ms) → Text change → Fade in (200ms)
- Interval: 4 seconds per descriptor
- Easing: `ease-in-out`

**Reduced Motion Fallback**:
```css
@media (prefers-reduced-motion: reduce) {
  .hero-subheadline {
    animation: none;
    opacity: 1;
  }
}
```

### 5.3 Scroll-Triggered Reveals

**Pattern**: Fade-in + translateY(30px → 0)

**Target Elements**:
- Section headlines
- Bento grid cards (staggered 100ms delay)
- Product cards (staggered by row)
- Subscription tier cards

**Implementation**:
- Trigger: Element enters viewport (Intersection Observer)
- Transform: `translateY(30px)` → `translateY(0)`
- Opacity: 0 → 1
- Duration: 600ms
- Easing: `--easing-elegant`
- Stagger: 100ms delay per element

**Reduced Motion**:
```css
@media (prefers-reduced-motion: reduce) {
  .reveal-element {
    transform: none;
    opacity: 1;
    transition: none;
  }
}
```

### 5.4 Ambient Video (Brewing Hub)

**Specifications**:
- Duration: 30-45 seconds looped
- Audio: Muted (silent)
- Controls: Hidden
- Autoplay: Yes (muted autoplay is allowed)
- Format: MP4 (H.264), WebM fallback
- Resolution: 1920×1080 (1080p)
- Optimization: <5MB file size, lazy load below fold

**Treatment**:
- Optional backdrop-blur overlay for text legibility
- Pause on `prefers-reduced-motion: reduce`

### 5.5 Animation Standards

**Duration Scale**:
- **Fast**: 150-250ms (immediate feedback)
- **Standard**: 300-400ms (most transitions)
- **Slow**: 500-600ms (luxury moments, page transitions)

**Easing Philosophy**:
- 90% use case: `cubic-bezier(0.4, 0.0, 0.2, 1)` (Material Design standard)
- 10% elegance: `cubic-bezier(0.25, 0.46, 0.45, 0.94)` (refined ease-out)
- Never: `linear` (too mechanical)

**Performance Rule**: Animate ONLY `transform` and `opacity` (GPU-accelerated). Never animate `width`, `height`, `margin`, `padding` (layout thrashing).

**Accessibility**: Always provide `prefers-reduced-motion: reduce` fallbacks that disable animations or reduce durations to 150ms.

---

## Validation Checklist

**✅ Style Guide Compliance**:
- Luxury & Sophisticated framework adapted with user's color palette
- Playfair Display + Inter Pro pairing implemented
- 96-128px spacing for premium feel
- 400-600ms animation timing for elegance

**✅ 2025 Trends Integration**:
- Mocha Mousse (#A47864) as anchor color per PANTONE 2025
- Kinetic typography in hero section
- Bento grid layouts for modular content
- Scroll-triggered reveals for storytelling
- Ambient video for immersive moments
- Tokenized CSS custom properties for theming

**✅ Premium Cafe Patterns**:
- Educational content hub (brewing guides)
- Subscription program with tier cards
- Coffee quiz CTA for guided discovery
- Accessibility statement commitment
- High-quality imagery requirements (4K hero)

**✅ Portfolio Showcase**:
- Advanced CSS Grid with named areas
- CSS custom properties for design tokens
- GPU-accelerated animations only
- WCAG AAA contrast for key pairings
- Mobile-first responsive strategy
- Performance optimization (WebP, lazy loading)

**✅ Technical Requirements Met**:
- ≤3K words (current: ~2,400 words) ✅
- 5 chapters ✅
- Max 6 components ✅
- 4pt spacing system ✅
- Visual patterns only (no filenames/content) ✅
- SPA specified in content plan ✅

**Word Count**: Approximately 2,400 words
