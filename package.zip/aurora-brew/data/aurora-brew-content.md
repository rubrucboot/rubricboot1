# Aurora Brew - Complete Content Library

## Brand Story

### About Aurora Brew
*Where Art Meets Science in Every Cup*

Aurora Brew represents the perfect harmony between traditional coffee craftsmanship and modern innovation. Founded in 2020 by award-winning roaster Sarah Chen and hospitality veteran Marcus Thompson, our café has become a destination for coffee enthusiasts who appreciate both the ritual and the science behind exceptional coffee.

We source exclusively from small-batch farms in Ethiopia, Colombia, and Costa Rica, building direct relationships with growers who share our commitment to sustainability and quality. Every bean is carefully selected, expertly roasted, and lovingly crafted into beverages that awaken both palate and spirit.

Our philosophy centers on three pillars: **Sustainability** - From farm to cup, we prioritize environmental responsibility; **Craftsmanship** - Our skilled baristas are trained in both traditional techniques and innovative brewing methods; **Community** - We create spaces where people connect, work, and find inspiration over exceptional coffee.

---

## Menu Categories

### Signature Espresso Drinks
**Aurora Espresso** - $3.50
Our house blend featuring notes of dark chocolate and caramelized orange. Perfectly balanced with a silky crema.

**Northern Lights Latte** - $4.75
Velvety espresso combined with house-made vanilla bean syrup and steamed milk, topped with latte art.

**Celestial Cappuccino** - $4.25
Equal parts espresso, steamed milk, and foam with a dusting of our signature spice blend.

**Stellar Macchiato** - $4.50
Espresso "marked" with a dollop of steamed milk foam, served in our signature ceramic cups.

### Seasonal Specialties
**Golden Hour Cold Brew** - $5.25
Slow-steeped for 18 hours with notes of honey and tropical fruit. Served over ice with choice of milk.

**Autumn Spice Latte** - $5.50
Pumpkin spice meets our premium espresso with house-made pumpkin syrup and autumn spices.

**Winter Solstice Hot Chocolate** - $4.75
Rich dark chocolate with house-made whipped cream and a sprinkle of cocoa nibs.

### Manual Brewing
**Pour Over Bar** - $6.00
Single-origin beans brewed to order using V60, Chemex, or French press. Ask our baristas for today's featured origin.

**Siphon Coffee** - $7.00
The theatrical brewing method that produces clean, bright flavors with floral aromatics.

**AeroPress Excellence** - $5.50
Innovative brewing that combines immersion and pressure for a unique flavor profile.

### Food Menu
**Avocado Toast Supreme** - $8.50
Sourdough bread with smashed avocado, heirloom tomatoes, microgreens, and everything seasoning.

**Quinoa Power Bowl** - $12.00
Roasted vegetables, quinoa, chickpeas, and tahini dressing. Perfect for health-conscious guests.

**Aurora Croissant** - $4.25
Flaky, buttery croissants baked fresh daily. Available plain, chocolate, or almond.

---

## Brewing Education Content

### The Science of Perfect Extraction
Coffee brewing is both art and science. The ideal extraction rate is between 18-22%, balancing sweetness, acidity, and body. Our baristas monitor variables like water temperature (195-205°F), grind size, and brew time to ensure every cup meets our exacting standards.

### Our Roasting Philosophy
We roast in small batches of 12-25 pounds, allowing us to carefully monitor each bean's development. Light roasts preserve the bean's origin characteristics and natural acidity. Medium roasts offer balanced flavor profiles, while our signature dark roasts bring out rich, chocolatey notes with reduced acidity.

### Sustainability Practices
- Direct trade relationships with 12 coffee farms
- 100% compostable packaging for all coffee sales
- Food waste composting program
- Energy-efficient roasting equipment
- Local sourcing for pastries and ingredients when possible

---

## Subscription Program

### The Aurora Club - Coffee Subscription Service

**Starter** - $22/month
- 1 bag (12oz) of our house blend or single-origin
- Free shipping
- Monthly brewing tips newsletter
- 10% discount on in-café purchases

**Explorer** - $38/month
- 2 bags of rotating single-origin coffees
- Free shipping
- Monthly coffee education content
- 15% discount on in-café purchases
- Exclusive access to limited releases

**Connoisseur** - $65/month
- 3 bags of premium single-origin selections
- Free shipping + priority processing
- Monthly virtual cupping sessions
- 20% discount on in-café purchases
- Invitation to quarterly coffee events
- Custom grinding options

---

## Location & Contact

### Aurora Brew Flagship Location
**Address:** 1247 Coffee Street, Arts District, Portland, OR 97205

**Hours:**
Monday - Friday: 6:30 AM - 8:00 PM
Saturday - Sunday: 7:00 AM - 9:00 PM

**Phone:** (503) 555-BREW
**Email:** hello@aurorabrew.com

### Visit Us
Located in the heart of Portland's Arts District, Aurora Brew is a 2,400 sq ft space featuring:
- 60 seats with a mix of communal and private seating
- Free high-speed WiFi throughout
- Dedicated workspace area with power outlets
- Outdoor patio seating (weather permitting)
- Private meeting room available for reservations
- Coffee roasting facility viewing area

### Transportation
- Street parking available
- Two blocks from MAX Light Rail (Pioneer Square station)
- Bike-friendly with secure parking
- Walking distance from major hotels and businesses

---

## Additional Content

### Awards & Recognition
- "Best New Coffee Shop" - Portland Coffee Awards 2021
- "Sustainability Champion" - Oregon Green Business Awards 2022
- "Outstanding Hospitality" - Portland Monthly 2023
- Good Food Awards Finalist 2024

### Community Involvement
- Partner with local nonprofits through our "Cups for a Cause" program
- Monthly charity blend supporting different local organizations
- Host coffee education workshops for aspiring baristas
- Support local artists with rotating wall exhibitions

### Newsletter Signup Benefits
- Weekly coffee updates and brewing tips
- Early access to new menu items and seasonal offerings
- Exclusive subscriber-only events and cuppings
- 10% discount on merchandise and subscriptions
