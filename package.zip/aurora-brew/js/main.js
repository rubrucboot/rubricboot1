/**
 * Aurora Brew - Main JavaScript
 * Modern interactions and animations
 */

// Global state
const App = {
  currentHeadlineIndex: 0,
  headlines: [],
  isMenuOpen: false,
  prefersReducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  menuData: null,
  subscriptionData: null,
  heroContent: null,
  locationData: null
};

// DOM Elements
const elements = {
  heroSubheadline: document.getElementById('hero-subheadline'),
  heroDescription: document.getElementById('hero-description'),
  navToggle: document.getElementById('nav-toggle'),
  navMenu: document.getElementById('nav-menu'),
  menuGrid: document.getElementById('menu-grid'),
  subscriptionGrid: document.getElementById('subscription-grid'),
  filterButtons: document.querySelectorAll('.filter-btn'),
  nav: document.getElementById('nav'),
  revealElements: document.querySelectorAll('.reveal, .section-header, .bento-card, .menu-card, .subscription-card, .brew-card')
};

/**
 * Initialize the application
 */
async function init() {
  try {
    // Load all data
    await loadData();
    
    // Initialize components
    initHero();
    initNavigation();
    initMenu();
    initSubscription();
    initScrollAnimations();
    initLocationInfo();
    
    // Setup event listeners
    setupEventListeners();
    
    console.log('Aurora Brew initialized successfully');
  } catch (error) {
    console.error('Failed to initialize Aurora Brew:', error);
  }
}

/**
 * Load all JSON data files
 */
async function loadData() {
  try {
    const [menuResponse, subscriptionResponse, heroResponse, locationResponse] = await Promise.all([
      fetch('./data/menu-items.json'),
      fetch('./data/subscription-tiers.json'),
      fetch('./data/hero-content.json'),
      fetch('./data/location-info.json')
    ]);

    App.menuData = await menuResponse.json();
    App.subscriptionData = await subscriptionResponse.json();
    App.heroContent = await heroResponse.json();
    App.locationData = await locationResponse.json();

    // Store headlines for rotation
    App.headlines = App.heroContent.brewing_guides.map(guide => guide.title);
  } catch (error) {
    console.error('Error loading data:', error);
    // Fallback to empty data
    App.menuData = { signature_drinks: [], seasonal_specialties: [], manual_brewing: [], food_menu: [] };
    App.subscriptionData = { subscription_tiers: [] };
    App.heroContent = { hero_content: { headlines: ['Crafted with Precision'] } };
    App.headlines = ['Crafted with Precision'];
  }
}

/**
 * Initialize hero section
 */
function initHero() {
  if (App.prefersReducedMotion) {
    // Set static content for reduced motion
    elements.heroSubheadline.textContent = App.heroContent.hero_content.headlines[0];
    return;
  }

  // Start headline rotation
  App.headlines = App.heroContent.hero_content.headlines;
  startHeadlineRotation();
}

/**
 * Start rotating headlines in hero section
 */
function startHeadlineRotation() {
  if (App.headlines.length <= 1) return;

  setInterval(() => {
    App.currentHeadlineIndex = (App.currentHeadlineIndex + 1) % App.headlines.length;
    
    elements.heroSubheadline.style.animation = 'none';
    setTimeout(() => {
      elements.heroSubheadline.textContent = App.headlines[App.currentHeadlineIndex];
      elements.heroSubheadline.style.animation = 'rotateHeadlines 4s ease-in-out';
    }, 10);
  }, 4000);
}

/**
 * Initialize navigation
 */
function initNavigation() {
  // Add scroll effect to nav
  window.addEventListener('scroll', handleNavScroll);
  
  // Setup mobile menu toggle
  elements.navToggle?.addEventListener('click', toggleMobileMenu);
  
  // Close mobile menu when clicking nav links
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.innerWidth <= 1024) {
        closeMobileMenu();
      }
    });
  });
}

/**
 * Handle navigation scroll effects
 */
function handleNavScroll() {
  const scrolled = window.scrollY > 50;
  elements.nav?.classList.toggle('scrolled', scrolled);
}

/**
 * Toggle mobile menu
 */
function toggleMobileMenu() {
  App.isMenuOpen = !App.isMenuOpen;
  elements.navMenu?.classList.toggle('open', App.isMenuOpen);
  elements.navToggle?.classList.toggle('open', App.isMenuOpen);
  document.body.classList.toggle('menu-open', App.isMenuOpen);
}

/**
 * Close mobile menu
 */
function closeMobileMenu() {
  App.isMenuOpen = false;
  elements.navMenu?.classList.remove('open');
  elements.navToggle?.classList.remove('open');
  document.body.classList.remove('menu-open');
}

/**
 * Initialize menu section
 */
function initMenu() {
  renderMenuItems();
  initMenuFiltering();
}

/**
 * Render menu items from data
 */
function renderMenuItems() {
  if (!App.menuData) return;

  const allItems = [
    ...App.menuData.signature_drinks,
    ...App.menuData.seasonal_specialties,
    ...App.menuData.manual_brewing,
    ...App.menuData.food_menu
  ];

  elements.menuGrid.innerHTML = allItems.map(item => createMenuCard(item)).join('');
}

/**
 * Create menu card HTML
 */
function createMenuCard(item) {
  const categoryClass = item.category.toLowerCase().replace(/\s+/g, '-');
  const imagePath = item.image.replace(/^imgs\//, 'images/');
  
  return `
    <div class="menu-card reveal" data-category="${categoryClass}">
      <div class="menu-card-image">
        <img src="${imagePath}" alt="${item.name}" loading="lazy">
      </div>
      <div class="menu-card-content">
        <h3 class="menu-card-title">${item.name}</h3>
        <p class="menu-card-description">${item.description}</p>
        <div class="menu-card-footer">
          <span class="menu-card-price">$${item.price.toFixed(2)}</span>
          <span class="menu-card-category">${item.category}</span>
        </div>
      </div>
    </div>
  `;
}

/**
 * Initialize menu filtering
 */
function initMenuFiltering() {
  elements.filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      
      // Update active button
      elements.filterButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      
      // Filter menu items
      filterMenuItems(filter);
    });
  });
}

/**
 * Filter menu items by category
 */
function filterMenuItems(filter) {
  const menuCards = document.querySelectorAll('.menu-card');
  
  menuCards.forEach(card => {
    const category = card.dataset.category;
    const shouldShow = filter === 'all' || category.includes(filter);
    
    if (shouldShow) {
      card.style.display = 'block';
      card.style.animation = 'fadeInUp 400ms ease-out';
    } else {
      card.style.display = 'none';
    }
  });
}

/**
 * Initialize subscription section
 */
function initSubscription() {
  if (!App.subscriptionData) return;

  elements.subscriptionGrid.innerHTML = App.subscriptionData.subscription_tiers
    .map(tier => createSubscriptionCard(tier))
    .join('');
}

/**
 * Create subscription card HTML
 */
function createSubscriptionCard(tier) {
  const recommendedClass = tier.highlighted ? 'recommended' : '';
  const badge = tier.highlighted ? '<div class="recommended-badge">Recommended</div>' : '';
  
  return `
    <div class="subscription-card reveal ${recommendedClass}">
      ${badge}
      <h3 class="tier-name">${tier.name}</h3>
      <p class="tier-description">${tier.description}</p>
      <div class="tier-price">
        $${tier.price}
        <span class="tier-period">/${tier.period}</span>
      </div>
      <ul class="tier-features">
        ${tier.features.map(feature => `
          <li>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="20,6 9,17 4,12"></polyline>
            </svg>
            ${feature}
          </li>
        `).join('')}
      </ul>
      <div class="tier-savings">${tier.savings}</div>
      <button class="btn btn-primary tier-cta">${tier.cta}</button>
    </div>
  `;
}

/**
 * Initialize scroll-triggered animations
 */
function initScrollAnimations() {
  if (App.prefersReducedMotion) return;

  // Create intersection observer for reveal animations
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        
        // Stagger animations for grid items
        if (entry.target.closest('.bento-grid') || 
            entry.target.closest('.menu-grid') || 
            entry.target.closest('.subscription-grid')) {
          const siblings = Array.from(entry.target.parentElement.children);
          const index = siblings.indexOf(entry.target);
          entry.target.style.animationDelay = `${index * 100}ms`;
        }
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -10% 0px'
  });

  // Observe all reveal elements
  elements.revealElements.forEach(element => {
    observer.observe(element);
  });
}

/**
 * Initialize location information
 */
function initLocationInfo() {
  // Add any dynamic location functionality here
  // For now, the location info is static in HTML
}

/**
 * Setup global event listeners
 */
function setupEventListeners() {
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', handleSmoothScroll);
  });

  // Handle window resize
  window.addEventListener('resize', handleResize);

  // Handle scroll for parallax effect on hero
  window.addEventListener('scroll', handleParallax);

  // Handle keyboard navigation
  document.addEventListener('keydown', handleKeydown);

  // Handle form submissions (if any forms are added)
  document.addEventListener('submit', handleFormSubmit);
}

/**
 * Handle smooth scroll for anchor links
 */
function handleSmoothScroll(e) {
  e.preventDefault();
  const targetId = e.currentTarget.getAttribute('href');
  const targetElement = document.querySelector(targetId);
  
  if (targetElement) {
    const offsetTop = targetElement.offsetTop - 80; // Account for fixed nav
    window.scrollTo({
      top: offsetTop,
      behavior: 'smooth'
    });
  }
}

/**
 * Handle window resize
 */
function handleResize() {
  // Close mobile menu on resize
  if (window.innerWidth > 1024) {
    closeMobileMenu();
  }
}

/**
 * Handle parallax effect on hero section
 */
function handleParallax() {
  if (App.prefersReducedMotion) return;

  const scrolled = window.pageYOffset;
  const heroImage = document.querySelector('.hero-image');
  
  if (heroImage && scrolled < window.innerHeight) {
    const rate = scrolled * -0.5;
    heroImage.style.transform = `translateY(${rate}px)`;
  }
}

/**
 * Handle keyboard navigation
 */
function handleKeydown(e) {
  // Close mobile menu on Escape key
  if (e.key === 'Escape' && App.isMenuOpen) {
    closeMobileMenu();
  }
  
  // Handle accessibility shortcuts
  if (e.ctrlKey || e.metaKey) {
    switch (e.key) {
      case '/':
        e.preventDefault();
        // Focus menu search (if implemented)
        break;
    }
  }
}

/**
 * Handle form submissions
 */
function handleFormSubmit(e) {
  e.preventDefault();
  // Handle any forms added to the site
  console.log('Form submitted:', e.target);
}

/**
 * Utility function to scroll to section
 */
function scrollToSection(sectionId) {
  const element = document.getElementById(sectionId);
  if (element) {
    const offsetTop = element.offsetTop - 80;
    window.scrollTo({
      top: offsetTop,
      behavior: 'smooth'
    });
  }
}

/**
 * Utility function to add loading states
 */
function setLoading(element, isLoading = true) {
  if (isLoading) {
    element.classList.add('loading');
    element.disabled = true;
  } else {
    element.classList.remove('loading');
    element.disabled = false;
  }
}

/**
 * Utility function for debouncing
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Performance monitoring
 */
function trackPerformance() {
  if ('performance' in window) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
      }, 0);
    });
  }
}

/**
 * Error handling
 */
window.addEventListener('error', (e) => {
  console.error('JavaScript error:', e.error);
  // Could send to error tracking service
});

window.addEventListener('unhandledrejection', (e) => {
  console.error('Unhandled promise rejection:', e.reason);
  // Could send to error tracking service
});

// Initialize the application when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export functions for global access
window.scrollToSection = scrollToSection;
window.setLoading = setLoading;

// Performance tracking
trackPerformance();

/**
 * Service Worker registration (if implementing PWA features)
 */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Uncomment when service worker is implemented
    // navigator.serviceWorker.register('/sw.js')
    //   .then(registration => console.log('SW registered'))
    //   .catch(error => console.log('SW registration failed'));
  });
}/**
 * Add scroll progress indicator
 */
function addScrollProgress() {
  const progressBar = document.createElement('div');
  progressBar.className = 'scroll-progress';
  document.body.appendChild(progressBar);

  window.addEventListener('scroll', () => {
    const scrolled = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
    progressBar.style.width = `${Math.min(scrolled, 100)}%`;
  });
}

/**
 * Add skip link for accessibility
 */
function addSkipLink() {
  const skipLink = document.createElement('a');
  skipLink.href = '#main';
  skipLink.className = 'skip-link';
  skipLink.textContent = 'Skip to main content';
  document.body.insertBefore(skipLink, document.body.body);
}

/**
 * Toast notification system
 */
const Toast = {
  show(message, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 100);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => document.body.removeChild(toast), 300);
    }, duration);
  }
};

/**
 * Enhanced navigation with accessibility
 */
function enhanceNavigation() {
  // Add ARIA labels
  const nav = document.querySelector('.nav');
  nav.setAttribute('role', 'navigation');
  nav.setAttribute('aria-label', 'Main navigation');

  // Add main content landmark
  const main = document.querySelector('.hero');
  if (main) {
    main.id = 'main';
    main.setAttribute('role', 'main');
  }
}

/**
 * Enhanced error handling for images
 */
function handleImageErrors() {
  document.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', (e) => {
      const img = e.target;
      const alt = img.getAttribute('alt') || 'Image';
      img.style.display = 'none';
      console.warn(`Failed to load image: ${alt}`);
    });
  });
}

/**
 * Enhanced intersection observer with error handling
 */
function createAdvancedObserver() {
  if (!('IntersectionObserver' in window)) {
    // Fallback for older browsers
    document.querySelectorAll('.reveal').forEach(el => {
      el.classList.add('active');
    });
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        
        // Add staggered animation delays
        const container = entry.target.parentElement;
        if (container) {
          const siblings = Array.from(container.children);
          const index = siblings.indexOf(entry.target);
          entry.target.style.animationDelay = `${index * 100}ms`;
        }
        
        // Unobserve after animation to improve performance
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  // Observe elements with error handling
  document.querySelectorAll('.reveal, .bento-card, .menu-card, .subscription-card').forEach(el => {
    try {
      observer.observe(el);
    } catch (error) {
      console.error('Error observing element:', el, error);
      el.classList.add('active');
    }
  });
}

/**
 * Performance monitoring and optimization
 */
function optimizePerformance() {
  // Lazy load images that are not in viewport
  const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      }
    });
  });

  // Observe all images with data-src attribute
  document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
  });

  // Debounced resize handler
  const debouncedResize = debounce(() => {
    // Handle responsive adjustments
    if (window.innerWidth <= 1024) {
      closeMobileMenu();
    }
  }, 250);

  window.addEventListener('resize', debouncedResize);
}

/**
 * Enhanced menu filtering with animations
 */
function enhanceMenuFiltering() {
  elements.filterButtons.forEach(button => {
    button.addEventListener('click', async (e) => {
      const filter = button.dataset.filter;
      
      // Update active button with animation
      elements.filterButtons.forEach(btn => {
        btn.classList.remove('active');
        btn.style.transform = 'scale(1)';
      });
      button.classList.add('active');
      button.style.transform = 'scale(1.05)';
      
      setTimeout(() => {
        button.style.transform = 'scale(1)';
      }, 200);
      
      // Filter with staggered animation
      const menuCards = document.querySelectorAll('.menu-card');
      menuCards.forEach((card, index) => {
        const category = card.dataset.category;
        const shouldShow = filter === 'all' || category.includes(filter);
        
        if (shouldShow) {
          card.style.display = 'block';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, index * 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translateY(20px)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 200);
        }
      });
    });
  });
}

/**
 * Add interactive elements
 */
function addInteractiveElements() {
  // Add hover effects to cards
  document.querySelectorAll('.menu-card, .subscription-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.zIndex = '10';
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.zIndex = '1';
    });
  });

  // Add click handlers for CTA buttons
  document.querySelectorAll('.tier-cta').forEach(button => {
    button.addEventListener('click', (e) => {
      setLoading(button, true);
      
      // Simulate API call
      setTimeout(() => {
        setLoading(button, false);
        Toast.show('Subscription feature coming soon! Subscribe to our newsletter for updates.');
      }, 1500);
    });
  });
}

/**
 * Enhanced scroll handling
 */
function enhanceScrollHandling() {
  let ticking = false;

  function updateScrollEffects() {
    const scrolled = window.pageYOffset;
    
    // Parallax effect for hero
    const heroImage = document.querySelector('.hero-image');
    if (heroImage && scrolled < window.innerHeight && !App.prefersReducedMotion) {
      const rate = scrolled * -0.3;
      heroImage.style.transform = `translateY(${rate}px)`;
    }

    // Update navigation
    const nav = document.querySelector('.nav');
    if (nav) {
      nav.classList.toggle('scrolled', scrolled > 50);
    }

    ticking = false;
  }

  function requestTick() {
    if (!ticking) {
      requestAnimationFrame(updateScrollEffects);
      ticking = true;
    }
  }

  window.addEventListener('scroll', requestTick);
}

/**
 * Add all enhancements
 */
function addEnhancements() {
  addScrollProgress();
  addSkipLink();
  enhanceNavigation();
  handleImageErrors();
  enhanceMenuFiltering();
  addInteractiveElements();
  enhanceScrollHandling();
  optimizePerformance();
}

// Call enhancements after initialization
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(addEnhancements, 100);
});

// Make Toast globally available
window.Toast = Toast;